<div class="login_form slide" style="margin:0 auto;padding:20px;margin-top:20px;width:400px;">
	An email has been sent to the email associated with that account. Visit your email to choose a new password.
</div>